Tiket_reguler = 40000
Tiket_VIP = 75000
Tiket_VVIP = 100000
while True:
    Banyak_tiket_dibeli = int(input("Jumlah Tiket yang dibeli = "))
    Jenis_tiket = input("Jenis tiket = ")
    Total_bayar_awal = Banyak_tiket_dibeli * Tiket_VIP
    Member_card = input("Masukkan ya atau tidak = ")
    if Jenis_tiket == "Tiket_reguler":
        print("Silahkan beli minuman 10000")
        Jawab = input("Jawaban Pembeli = ")
    elif Jenis_tiket == "Tiket_VIP" and "Tiket_VVIP":
        print("Mendapat minuman gratis setelah membayar")
    if Banyak_tiket_dibeli == 3:
        if Member_card == "ya":
            print("Mendapat diskon 15%")
            Total_bayar_setelah_diskon =Total_bayar_awal - 15/100
            print("Total bayar akhir = ", Total_bayar_setelah_diskon)
        else:
            print("Mendapat diskon 10%")
            Total_bayar_setelah_diskon =Total_bayar_awal - 15/100
    print("Total bayar akhir = ", Total_bayar_setelah_diskon)
    Nominal_uang = int("Nominal uang = ")
    Kembalian = Nominal_uang - Total_bayar_setelah_diskon
    print("Kembalian")


    #menghitung tiket YG DIBELI
